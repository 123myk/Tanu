﻿using CodeFirstWithMVC.Models;
using System;
using System.Collections.Generic;
using CodeFirstWithMVC.DataBase;

namespace CodeFirstWithMVC.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        EmployeeDBContext objContext;    //With the help of objContext we can perform DML, fetch,search operations.
        public EmployeeRepository()
        {
            objContext = new EmployeeDBContext();
        }

        int IEmployeeRepository.CreateEmployee(Employee emp)
        {
            objContext.Employees.Add(emp); //It will add in local memory
            return objContext.SaveChanges();      //Commit to database
            
        }

        IEnumerable<Employee> IEmployeeRepository.GetEmployeeDetails()
        {
            throw new NotImplementedException();
        }
    }
}