﻿using System;
using System.Collections.Generic;
using CodeFirstWithMVC.Models;

namespace CodeFirstWithMVC.Repository
{
    public interface IEmployeeRepository
    {
        IEnumerable<Employee> GetEmployeeDetails();  //To fetch complete records
        int CreateEmployee(Employee emp);
    }
}
