﻿using System;
using CodeFirstWithMVC.Models;
using System.Web.Mvc;
using CodeFirstWithMVC.Repository;

namespace CodeFirstWithMVC.Controllers
{
    public class EmployeeController : Controller
    {
        IEmployeeRepository employeeRepository = new EmployeeRepository();  //Abstraction Model
        // GET: Employee
        [HttpGet]
        public ActionResult CreateEmployee()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateEmployee(Employee employee)
        {
            int result = employeeRepository.CreateEmployee(employee);
            if (result > 0)
            {
                Response.Write("Record is saved succussfully");
            }
            else
                Response.Write("Record is not saved");
            //Response.Write(employee.name+" "+employee.age+" "+employee.email);
            return View();
        }
    }
}