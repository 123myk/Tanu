﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CodeFirstWithMVC.Models
{
    public class Employee
    {
         //Id will be primary key with the help of [Key annotation]
        public int id { get; set; }
        //[Required(ErrorMessage ="Name is required")]
        public string name { get; set; }
        public int age { get; set; }
        public string email { get; set; }
    }
}