﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using CodeFirstWithMVC.Models;

namespace CodeFirstWithMVC.DataBase
{
    public class EmployeeDBContext:DbContext  //DbContext will recieve the connection string to create the database and also helps for the DML operations
    {
        public EmployeeDBContext(): base("myConnection")      //myConnection will be connection string
        {

        }

        public DbSet<Employee> Employees { get; set;}  //Employees will be table name and number of columns dependent on DbSet class.
                                                       //1 Table = 1 DbSet<Invoice> invoices {get;set;}
                                                       //To fetch,to search
    }
    //Whatever table name we will be accessing by pointer known as Employees or we can say Employees is a alias of actual table name

}